key = ""
format_response = "json" # Ou "xml"
